// src/lib/components/textOverlay/index.ts
/**
 * TextOverlay module exports
 * 
 * Usage:
 * import { TextOverlay, GoogleFonts } from '$lib/components/textOverlay';
 */

//export { default as TextOverlay } from './TextOverlay.svelte';
export { default as GoogleFonts } from './GoogleFonts.svelte';