<div class="flex max-w-md flex-col gap-4 rounded-box bg-base-200 p-6">
	<h1 class="self-center text-3xl font-bold">Log in</h1>

	<span class="self-center">
		Don't have an account?
		<button class="link link-secondary">Register</button>
	</span>

	<button class="btn btn-neutral">
		<i class="fa-brands fa-google text-primary"></i>
		Log in with Google
	</button>

	<div class="divider">OR</div>

	<label class="form-control">
		<div class="label">
			<span class="label-text">Email</span>
		</div>

		<input class="input-bordered input" />
	</label>

	<label class="form-control">
		<div class="label">
			<span class="label-text">Password</span>
			<button class="label-text link link-accent">Forgot password?</button>
		</div>

		<input type="password" class="input-bordered input" />
	</label>

	<div class="form-control">
		<label class="label cursor-pointer gap-2 self-start">
			<input type="checkbox" class="checkbox" />
			<span class="label-text">Remember me</span>
		</label>
	</div>

	<button class="btn btn-primary">Log in</button>
</div>
