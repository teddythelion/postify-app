<footer class="footer bg-base-200 p-10 text-base-content sm:footer-horizontal">
	<nav>
		<h6 class="footer-title">Services</h6>
		<a href="/" class="link link-hover">Branding</a>
		<a href="/" class="link link-hover">Design</a>
		<a href="/" class="link link-hover">Marketing</a>
		<a href="/" class="link link-hover">Advertisement</a>
	</nav>
	<nav>
		<h6 class="footer-title">Company</h6>
		<a href="/" class="link link-hover">About us</a>
		<a href="/" class="link link-hover">Contact</a>
		<a href="/" class="link link-hover">Jobs</a>
		<a href="/" class="link link-hover">Press kit</a>
	</nav>
	<nav>
		<h6 class="footer-title">Legal</h6>
		<a href="/" class="link link-hover">Terms of use</a>
		<a href="/" class="link link-hover">Privacy policy</a>
		<a href="/" class="link link-hover">Cookie policy</a>
	</nav>
	<form>
		<h6 class="footer-title">Newsletter</h6>
		<fieldset class="w-80">
			<span>Enter your email address</span>
			<div class="join">
				<input type="text" placeholder="username@site.com" class="input-bordered input join-item" />
				<button class="btn join-item btn-primary">Subscribe</button>
			</div>
		</fieldset>
	</form>
</footer>
